package com.example.demo.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author ziming.xing
 * Create Date：2023/1/4
 */
@Slf4j
@RequestMapping
@RestController
public class DemoController {
    @GetMapping("/")
    public Object index() {
        log.info("index");
        return "Change the world";
    }

    @GetMapping("/hello")
    public Object hello() {
        log.info("Hello");
        return "Hello World";
    }

    @GetMapping("/health")
    public Object health() {
        log.info("health");
        return HttpStatus.OK.getReasonPhrase();
    }
}
