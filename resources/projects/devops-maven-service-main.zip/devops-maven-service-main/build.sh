mvn clean package && mvn test
